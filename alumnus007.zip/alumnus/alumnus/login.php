<html>
<title> MNNIT Alumnus </title>

<head>
    <link rel="stylesheet" href="./dropmenu.css">
<script>
function validateForm() {
    var x = document.forms["myForm"]["x"].value;
	var y = document.forms["myForm"]["y"].value;
    var a = document.forms["myForm"]["a"].value;
	
    if (a=="") 
    {
        alert("Please choose a Placement Type !!");
        return false;
    }
	else if (y=="" ) 
    {
        alert("Enter something to search !!");
        return false;
    }
	else if (x=="" ) 
    {
        alert("Please choose a Search Category !!");
        return false;
    }
    return true;
}
</script>
</head>


<body background=".\Images\a.jpg">

<table border=0 width="100%">
<tr>
<td width="10%"></td>
<td width="15%" align="right"><img src=".\Images\l.png" title="MNNIT Allahabad Logo" height="50%"></td>
<td width="75%" align="center"><img src=".\Images\n.png" height="80%"></td>
</tr>
</table>
<hr>

<div id='cssmenu'>
<ul>
    <li class='active '><a href="index.php"><span>Home</span></a></li>
    <li><a href='companies.html'><span>Companies Visiting</span></a></li>
    <li><a href=''><span>Internship Portal</span></a></li> 
    <li><a href=''><span>Placements Portal</span></a></li> 
    <li><a href='about.html' ><span>About</span></a></li>
    <li><a href='login.html'><span>Log In</span></a></li>  
</ul>
         

</div>
<br>

<center>
<h1><font face="Cambria"><b>MNNIT Allahabad Alumni Placement Database System</b></font></h1>
<br><center>
Welcome Admin

<?php
$name=$_POST['username'];
$pass=$_POST['password'];

if(empty($name) || empty($pass)) 
{
echo "<center><font size='5' color='red' face='Comic Sans MS'>Data Incomplete !!";
}
else 
{
	if(($name=='admin') && ($pass=='admin'))
	{
		session_start();
		$_SESSION['name']=$name;
			header ("location:welcome.html");
	}
	else
	{
		echo "<center><font size='5' color='red' face='Comic Sans MS'>Invalid Credentials.!!";
	}
}		
?>

</body>
</html>
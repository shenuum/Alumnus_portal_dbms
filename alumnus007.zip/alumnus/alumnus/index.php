<html>
<title> MNNIT Alumnus </title>

<head>
    <link rel="stylesheet" href="./dropmenu.css">
<script>
function validateForm() {
    var x = document.forms["myForm"]["x"].value;
	var y = document.forms["myForm"]["y"].value;
    var a = document.forms["myForm"]["a"].value;
	
    if (a=="") 
    {
        alert("Please choose a Placement Type !!");
        return false;
    }
	else if (y=="" ) 
    {
        alert("Enter something to search !!");
        return false;
    }
	else if (x=="" ) 
    {
        alert("Please choose a Search Category !!");
        return false;
    }
    return true;
}
</script>
</head>


<body background=".\Images\a.jpg">

<table border=0 width="100%">
<tr>
<td width="10%"></td>
<td width="15%" align="right"><img src=".\Images\l.png" title="MNNIT Allahabad Logo" height="50%"></td>
<td width="75%" align="center"><img src=".\Images\n.png" height="80%"></td>
</tr>
</table>
<hr>

<div id='cssmenu'>
<ul>
    <li class='active '><a href="index.php"><span>Home</span></a></li>
    <li><a href='companies.php'><span>Companies Visiting</span></a></li>
    <li><a href='http://172.31.13.135/intern/sip/'><span>Internship Portal</span></a></li> 
    <li><a href='http://172.31.13.135/tpo/spp/'><span>Placements Portal</span></a></li> 
    <li><a href='about.html' ><span>About</span></a></li>
    <li><a href='login.html'><span>Log In</span></a></li>  
</ul>
</div>
<br>

<center>
<h1><font face="Cambria"><b>MNNIT Allahabad Alumni Placement Database System</b></font></h1>

<form name="myForm" onsubmit="return validateForm()" method="POST" action="search.php"><br>
<font face="Cambria" size="5">
<b>Search on the basis of : </b> (Choose one)
	<select name="x" type="text">  
		<option value="Batch">Batch</option>
		<option value="Student Name">Student Name</option>
		<option value="Company Name">Company Name</option>
		<option value="Department">Department</option>
		<option value="Branch">Branch</option>
		<option value="Location">Location</option>
</select><br>

<b>Select Placement Type : </b> (Choose one)
	<select name="a" type="text">  
		<option value="FTR">Full Time Role</option>
		<option value="IR">Internship Role</option>
</select><br>
<b>Search Here</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text" name="y" size="40"><br>
<input type="submit" value ="Let's Go!">&nbsp;&nbsp;&nbsp;&nbsp;
<input type="reset" value ="Reset"><br>
</font>
</form>


</body>
</html>
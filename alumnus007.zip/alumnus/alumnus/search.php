<html>
<title> MNNIT Alumnus </title>

<head>
    <link rel="stylesheet" href="./dropmenu.css">
</head>


<body background=".\Images\a.jpg">

<table border=0 width="100%">
<tr>
<td width="10%"></td>
<td width="15%" align="right"><img src=".\Images\l.png" title="MNNIT Allahabad Logo" height="50%"></td>
<td width="75%" align="center"><img src=".\Images\n.png" height="80%"></td>
</tr>
</table>
<hr>

<div id='cssmenu'>
<ul>
    <li class='active '><a href="index.php"><span>Home</span></a></li>
    <li><a href='companies.php'><span>Companies Visiting</span></a></li>
    <li><a href='http://172.31.13.135/intern/sip/'><span>Internship Portal</span></a></li> 
    <li><a href='http://172.31.13.135/tpo/spp/'><span>Placements Portal</span></a></li> 
    <li><a href='about.html' ><span>About</span></a></li>
    <li><a href='login.html'><span>Log In</span></a></li>  
</ul>
         

</div>
<br>

<center>
<h1><font face="Cambria"><b>MNNIT Allahabad Alumni Placement Database System</b></font></h1>
<br>
<?php
session_start();
$x=$_POST['x'];
$a=$_POST['a'];
$y=$_POST['y'];

	mysql_connect("localhost","root","");
	mysql_select_db("alumnus");
	$z='%';
	$name=$z.$y.$z;
	
	if($x=="Batch")
	{
		if($a=="FTR")
		{
			$q="SELECT * FROM studentdetails NATURAL JOIN (companydetails NATURAL JOIN placementdetails) where batch like'%%$y%%' order by batch,ctc DESC;";	
		}
		elseif($a=="IR")
		{
			$q="SELECT * FROM studentdetails NATURAL JOIN (companydetails NATURAL JOIN internshipdetails) where batch like'%%$y%%' order by batch;";
		}
	}	

	elseif($x=="Student Name")
	{
		if($a=="FTR")
		{
			$q="SELECT * FROM studentdetails NATURAL JOIN (placementdetails NATURAL JOIN companydetails) where name like'%%$y%%' order by batch,ctc DESC;";
		}
		else
		{
			$q="SELECT * FROM studentdetails NATURAL JOIN (internshipdetails NATURAL JOIN companydetails) where name like'%%$y%%' order by batch,ctc DESC;";
		}
	}

	elseif($x=="Department")
	{
		if($a=="FTR")
		{
			$q="SELECT * FROM studentdetails NATURAL JOIN (companydetails NATURAL JOIN placementdetails) where dept like'%%$y%%' order by batch,ctc DESC;";	
		}
		elseif($a=="IR")
		{
			$q="SELECT * FROM studentdetails NATURAL JOIN (companydetails NATURAL JOIN internshipdetails) where dept like'%%$y%%' order by batch,ctc DESC;";
		}
	}

	elseif($x=="Location")
	{
		if($a=="FTR")
		{
			$q="SELECT * FROM studentdetails NATURAL JOIN (companydetails NATURAL JOIN placementdetails) where location like'%%$y%%' order by batch,ctc DESC;";	
		}
		elseif($a=="IR")
		{
			$q="SELECT * FROM studentdetails NATURAL JOIN (companydetails NATURAL JOIN internshipdetails) where location like'%%$y%%' order by batch,ctc DESC;";
		}
	}
	
	elseif($x=="Company Name")
	{
		if($a=="FTR")
		{
			$q="SELECT * FROM studentdetails NATURAL JOIN (placementdetails NATURAL JOIN companydetails) where companyname like'%%$y%%' order by batch,ctc DESC;";
		}
		else
		{
			$q="SELECT * FROM studentdetails NATURAL JOIN (internshipdetails NATURAL JOIN companydetails) where companyname like'%%$y%%' order by batch,ctc DESC;";
		}
	}

	elseif($x=="Branch")
	{
		if($a=="FTR")
		{
			$q="SELECT * FROM studentdetails NATURAL JOIN (companydetails NATURAL JOIN placementdetails) where branch like'%%$y%%' order by batch,ctc DESC;";	
		}
		elseif($a=="IR")
		{
			$q="SELECT * FROM studentdetails NATURAL JOIN (companydetails NATURAL JOIN internshipdetails) where branch like'%%$y%%' order by batch,ctc DESC;";
		}
	}
			$result=mysql_query($q);
			$count=mysql_num_rows($result);
			if($count==0)
				echo "No records found.!!";
			else
			{
				$v=1;
				echo "<table border='2' width='100%'>";
				echo "<tr>";
					echo "<td><b><center> Sr. No. </td>";
					echo "<td><b><center> Registration Number </td>";
					echo "<td><b><center> Student Name </td>";
					echo "<td><b><center> Batch </td>";
					echo "<td><b><center> Department </td>";
					echo "<td><b><center> Branch </td>";
					echo "<td><b><center> Contact </td>";
					echo "<td><b><center> Company Name </td>";
					echo "<td><b><center> Location </td>";
					echo "<td><b><center> Profile </td>";
					echo "<td><b><center> CTC/Stipend </td>";
					echo "</tr>";

				while($row=mysql_fetch_array($result))
				{
				echo "<tr>";
					echo "<td><center>",$v,"</td>";
					$v=$v+1;
					echo "<td><center>",$row["studentid"],"</td>";
					echo "<td><center>",$row["name"],"</td>";
					echo "<td><center>",$row["batch"],"</td>";
					echo "<td><center>",$row["dept"],"</td>";
					echo "<td><center>",$row["branch"],"</td>";
					echo "<td><center>",$row["contact"],"</td>";
					echo "<td><center>",$row["companyname"],"</td>";
					echo "<td><center>",$row["location"],"</td>";
					echo "<td><center>",$row["profile"],"</td>";
					echo "<td><center>",$row["ctc"],"</td>";
					
				echo "</tr>";
				}
				echo "</table>";
			}
	
?>

</body>
</html>